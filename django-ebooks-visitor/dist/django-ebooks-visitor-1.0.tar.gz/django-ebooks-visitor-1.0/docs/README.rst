===============
ebooks-Visitor
===============


Warning: includes only backend code.


Technologies Used:
-------------------
* Mysql database
* Of course Python and Django


